import React, { useState, useEffect } from "react";
import "./item.css";
import axios from "axios";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCheckCircle,
  faInfoCircle,
  faExclamationCircle,
  faBug,
} from "@fortawesome/free-solid-svg-icons";

function Item(props) {
  const [type, setType] = useState("");
  const [item, setItem] = useState([]);
  const [causedBy, setCausedBy] = useState([]);
  var { itemName, itemDescription, symptoms, image } = "";
  var cures = []

  useEffect(() => {
    let id = props.match.params.id;
    setType(props.match.params.type);
    // console.log(id);
    // console.log(props.match.params.type);

    axios
      .get("http://localhost:3000/" + props.match.params.type + "/" + id)
      .then((response) => {
        console.log(response.data);
        setItem(response.data);
        if (props.match.params.type === "disease") {
          axios
            .post("http://localhost:3000/pest/list/", {
              list: response.data.causedBy,
            })
            .then((response) => {
              console.log(response.data.result);
              // causedBy = response.data;
              setCausedBy(response.data.result);
              // console.log(causedBy)
            })
            .catch(function (error) {
              console.log(error);
            });
        }
      })
      .catch(function (error) {
        console.log(error);
      });
  }, []);

  if (type === "disease") {
    itemName = item.diseaseName;
    itemDescription = item.description;
    cures = item.cures;
    symptoms = item.symptoms;
    image = item.diseaseImage;
  }

  const sidebar = () => {
    var items = causedBy.map((item, key) => (
      <p className="item-div-content" key={item._id}>
        {item.pestName}
      </p>
    ));
    return (
      <div className="item-sidebar-div">
        <div className="item-causedby-div">
          <h4 className="sidebar-div-heading">
            <FontAwesomeIcon className="item-heading-icon" icon={faBug} />
            Caused By
          </h4>
          {items}
        </div>
      </div>
    );
  };



  const postBody = () => {
    // console.log(item);
    // var curesDisplay = cures.map((item, key) => (
    //   <p className="item-div-content" key={key}>
    //     {item}
    //   </p>
    // ));
    return (
      <div className="item-body-div">
        <div className="item-heading-div">
          <h3 className="item-title">{itemName}</h3>
        </div>
        <div className="item-image-div">
          <img className="item-image" src={image} alt={itemName} />
        </div>
        <div className="item-desc-div">
          <h3 className="item-div-heading">
            <FontAwesomeIcon
              className="item-heading-icon"
              icon={faInfoCircle}
            />
            Description
          </h3>
          <p className="item-div-content">{itemDescription}</p>
        </div>
        <div className="item-symp-div">
          <h3 className="item-div-heading">
            <FontAwesomeIcon
              className="item-heading-icon"
              icon={faExclamationCircle}
            />
            {type === "disease" ? "Symptoms" : "Diagnostics"}
          </h3>
          <p className="item-div-content">{symptoms}</p>
        </div>
        <div className="item-cures-div">
          <h3 className="item-div-heading">
            <FontAwesomeIcon
              className="item-heading-icon"
              icon={faCheckCircle}
            />
            Cures
          </h3>
          <p className="item-div-content">{cures}</p>
          {/* {curesDisplay} */}
        </div>
      </div>
    );
  };

  return (
    <div className="item-page-body">
      {sidebar()}
      {postBody()}
    </div>
  );
}

export default Item;
